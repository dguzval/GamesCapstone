const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

// =====================
// Input Handling
// =====================
const keys = {};
const mouse = {
    x: 0,
    y: 0,
    down: false
};

window.addEventListener("keydown", e => keys[e.key.toLowerCase()] = true);
window.addEventListener("keyup", e => keys[e.key.toLowerCase()] = false);

canvas.addEventListener("mousemove", e => {
    const rect = canvas.getBoundingClientRect();
    mouse.x = e.clientX - rect.left;
    mouse.y = e.clientY - rect.top;
});

canvas.addEventListener("mousedown", () => mouse.down = true);
canvas.addEventListener("mouseup", () => mouse.down = false);



// =====================
// Player Stats (Upgradeable later)
// =====================
class Stats {
    constructor() {
        this.maxHealth = 200;
        this.health = 200;
        this.damage = 10;
        this.speed = 2.5;
        this.range = 200;
        this.fireRate = 300; // ms between shots
    }
}

// =====================
// Player
// =====================
class Player {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.radius = 15;
        this.stats = new Stats();
        this.angle = 0;
        this.lastShot = 0;
        this.coins = 0;
    }

    update(deltaTime) {
        // Movement
        let dx = 0, dy = 0;
        if (keys["w"]) dy -= 1;
        if (keys["s"]) dy += 1;
        if (keys["a"]) dx -= 1;
        if (keys["d"]) dx += 1;

        const length = Math.hypot(dx, dy);
        if (length > 0) {
            dx /= length;
            dy /= length;
            const moveX = dx * this.stats.speed;
            const moveY = dy * this.stats.speed;
            moveWithWallCollision(this, moveX, moveY);
        }

        // Aim
        this.angle = Math.atan2(mouse.y - this.y, mouse.x - this.x);

        // Shoot
        if (mouse.down) {
            this.shoot();
        }
    }

    shoot() {
        const now = performance.now();
        if (now - this.lastShot < this.stats.fireRate) return;

        this.lastShot = now;
        bullets.push(new Bullet(
            this.x,
            this.y,
            this.angle,
            this.stats.damage,
            this.stats.range,
            "player"
        ));
    }



    draw() {
        // Tank body
        ctx.fillStyle = "green";
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
        ctx.fill();

        // Tank barrel
        ctx.strokeStyle = "darkgreen";
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.moveTo(this.x, this.y);
        ctx.lineTo(
            this.x + Math.cos(this.angle) * 25,
            this.y + Math.sin(this.angle) * 25
        );
        ctx.stroke();

        // Healthbar
        const barWidth = 30;
        const healthRatio = this.stats.health / this.stats.maxHealth;
        ctx.fillStyle = "red";
        ctx.fillRect(this.x - 15, this.y - 25, barWidth, 4);
        ctx.fillStyle = "lime";
        ctx.fillRect(this.x - 15, this.y - 25, barWidth * healthRatio, 4);
    }
}

class Enemy {
    constructor(x, y, typeKey = "basic") {
        const type = EnemyTypes[typeKey];

        this.typeKey = typeKey;
        this.name = type.name;
        this.bodyColor = type.bodyColor;
        this.barrelColor = type.barrelColor;

        this.x = x;
        this.y = y;
        this.radius = type.radius;
        this.stats = new Stats();
        this.stats.maxHealth = type.health;
        this.stats.health = type.health;
        this.stats.damage = type.damage;
        this.stats.speed = type.speed;
        this.stats.range = type.range;
        this.stats.fireRate = type.fireRate;

        this.coinValue = type.coinReward;

        this.angle = 0;
        this.lastShot = 0;
    }

    update(player) {
        // Aim at player
        this.angle = Math.atan2(player.y - this.y, player.x - this.x);

        // Move toward player
        const dx = Math.cos(this.angle);
        const dy = Math.sin(this.angle);
        const moveX = dx * this.stats.speed;
        const moveY = dy * this.stats.speed;
        const dist = Math.sqrt((player.y - this.y) * (player.y - this.y) + (player.x - this.x) * (player.x - this.x));
        if (dist <= 250) {
            moveWithWallCollision(this, moveX, moveY);
        }

        // Shoot
        const now = performance.now();
        if (now - this.lastShot > this.stats.fireRate) {
            this.lastShot = now;
            bullets.push(new Bullet(
                this.x,
                this.y,
                this.angle,
                this.stats.damage,
                this.stats.range,
                "enemy"
            ));
        }
    }

    draw() {
        // Body
        ctx.fillStyle = this.bodyColor;
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
        ctx.fill();

        // Barrel
        ctx.strokeStyle = this.barrelColor;
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.moveTo(this.x, this.y);
        ctx.lineTo(
            this.x + Math.cos(this.angle) * this.radius * 1.5,
            this.y + Math.sin(this.angle) * this.radius * 1.5
        );
        ctx.stroke();

        // Health bar
        const barWidth = 30;
        const healthRatio = this.stats.health / this.stats.maxHealth;
        ctx.fillStyle = "red";
        ctx.fillRect(this.x - 15, this.y - 25, barWidth, 4);
        ctx.fillStyle = "lime";
        ctx.fillRect(this.x - 15, this.y - 25, barWidth * healthRatio, 4);
    }
}


// =====================
// Bullets
// =====================
class Bullet {
    constructor(x, y, angle, damage, range, owner) {
        this.x = x;
        this.y = y;
        this.speed = 6;
        this.dx = Math.cos(angle);
        this.dy = Math.sin(angle);
        this.damage = damage;
        this.range = range;
        this.distanceTraveled = 0;
        this.radius = 3;
        this.owner = owner; // "player" or "enemy"
    }

    update() {
        this.x += this.dx * this.speed;
        this.y += this.dy * this.speed;
        this.distanceTraveled += this.speed;
    }

    draw() {
        ctx.fillStyle = this.owner === "player" ? "yellow" : "red";
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
        ctx.fill();
    }

    isOutOfRange() {
        return this.distanceTraveled > this.range;
    }
}

class Wall {
    constructor(x, y, width, height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    draw() {
        ctx.fillStyle = "#666";
        ctx.fillRect(this.x, this.y, this.width, this.height);
    }
}

class Door {
    constructor(x, y, w, h) {
        this.x = x;
        this.y = y;
        this.width = w;
        this.height = h;
        this.locked = true;
    }

    draw() {
        ctx.fillStyle = this.locked ? "darkred" : "lime";
        ctx.fillRect(this.x, this.y, this.width, this.height);
    }
}

class SlotMachine {
    constructor(columns, rows) {
        this.columns = columns;
        this.rows = rows;
        this.spinCost = 5;
        this.isEmpty = true;

        this.grid = [];          // grid[col][row]
        this.selected = [];      // selected[rowIndex] per column

        this.cellWidth = 160;
        this.cellHeight = 50;
        this.x = 300;
        this.y = 260;

        this.nextButton = { x: this.x, y: this.y + this.rows * this.cellHeight + 50, w: 260, h: 40 };

        this.clear();
    }

    resize(newCols, newRows) {
        this.columns = Math.min(newCols, SLOT_MACHINE_LIMITS.maxCols);
        this.rows = Math.min(newRows, SLOT_MACHINE_LIMITS.maxRows);
        this.clear();
    }

    clear() {
        this.grid = [];
        this.selected = [];
        for (let c = 0; c < this.columns; c++) {
            this.grid[c] = [];
            this.selected[c] = null;
            for (let r = 0; r < this.rows; r++) {
                this.grid[c][r] = null;
            }
        }
        this.isEmpty = true;
    }

    spin() {
        if (!this.isEmpty) return;
        if (player.coins < this.spinCost) return;

        player.coins -= this.spinCost;
        this.isEmpty = false;

        for (let c = 0; c < this.columns; c++) {
            for (let r = 0; r < this.rows; r++) {
                const rand = Math.floor(Math.random() * upgradePool.length);
                this.grid[c][r] = upgradePool[rand];
            }
        }
    }

    applySelections() {
        if (this.isEmpty) return;
        for (let c = 0; c < this.columns; c++) {
            const r = this.selected[c];
            if (r !== null) {
                this.grid[c][r].apply(player);
            }
        }
        this.clear();
    }

    handleClick(mx, my) {
        if (this.isEmpty) return;
        for (let c = 0; c < this.columns; c++) {
            for (let r = 0; r < this.rows; r++) {
                const cx = this.x + c * this.cellWidth;
                const cy = this.y + r * this.cellHeight;

                if (
                    mx >= cx && mx <= cx + this.cellWidth &&
                    my >= cy && my <= cy + this.cellHeight
                ) {
                    // Only one choice per column
                    this.selected[c] = r;
                }
            }
        }
    }

    draw() {
        ctx.font = "14px monospace";
        ctx.textAlign = "center";

        for (let c = 0; c < this.columns; c++) {
            for (let r = 0; r < this.rows; r++) {
                const x = this.x + c * this.cellWidth;
                const y = this.y + r * this.cellHeight;

                const isSelected = this.selected[c] === r;

                ctx.fillStyle = this.isEmpty
                    ? "rgba(50,50,50,0.6)"        // dim when empty
                    : (isSelected ? "rgba(0,255,0,0.5)" : "rgba(0,0,0,0.7)");
                ctx.fillRect(x, y, this.cellWidth - 4, this.cellHeight - 4);

                ctx.strokeStyle = "white";
                ctx.strokeRect(x, y, this.cellWidth - 4, this.cellHeight - 4);

                const upgrade = this.grid[c][r];
                if (!this.isEmpty && upgrade) {
                    ctx.fillStyle = "white";
                    ctx.fillText(
                        upgrade.name,
                        x + this.cellWidth / 2,
                        y + this.cellHeight / 2 + 5
                    );
                }
            }
        }

        // Spin button
        ctx.fillStyle = "gold";
        ctx.fillRect(this.x, this.y + this.rows * this.cellHeight + 10, 120, 30);
        ctx.fillStyle = "black";
        ctx.textAlign = "center";
        ctx.fillText(
            `Spin (${this.spinCost})`,
            this.x + 60,
            this.y + this.rows * this.cellHeight + 32
        );

        // Apply button
        ctx.fillStyle = "lime";
        ctx.fillRect(this.x + 140, this.y + this.rows * this.cellHeight + 10, 120, 30);
        ctx.fillStyle = "black";
        ctx.fillText(
            "Apply",
            this.x + 200,
            this.y + this.rows * this.cellHeight + 32
        );

    }

    handleButtonClick(mx, my) {
        // Spin button
        const spinX = this.x;
        const spinY = this.y + this.rows * this.cellHeight + 10;
        if (this.isEmpty && mx >= spinX && mx <= spinX + 120 && my >= spinY && my <= spinY + 30) {
            this.spin();
        }

        // Apply button
        const applyX = this.x + 140;
        const applyY = spinY;
        if (!this.isEmpty && this.allSlotsSelected() && mx >= applyX && mx <= applyX + 120 && my >= applyY && my <= applyY + 30) {
            this.applySelections();
        }

        // Next Level button
        const nextY = this.nextButton.y + this.rows * this.cellHeight - 100;
        if (this.isEmpty && readyForNextLevel &&
            mx >= this.nextButton.x &&
            mx <= this.nextButton.x + this.nextButton.w &&
            my >= nextY &&
            my <= nextY + this.nextButton.h
        ) {
            readyForNextLevel = false;
            loadLevel(currentLevelIndex);
            setGameState("playing");
        }
    }

    allSlotsSelected() {
        for (let c = 0; c < this.columns; c++) {
            if (this.selected[c] === null) {
                return false;
            }
        }
        return true;
    }

    drawNextLevelButton() {
        if (!readyForNextLevel) return;

        ctx.fillStyle = "deepskyblue";
        ctx.fillRect(this.nextButton.x, this.nextButton.y + this.rows * this.cellHeight - 100, this.nextButton.w, this.nextButton.h);

        ctx.fillStyle = "black";
        ctx.textAlign = "center";
        ctx.font = "18px sans-serif";
        ctx.fillText(
            "Next Level",
            this.nextButton.x + this.nextButton.w / 2,
            this.nextButton.y + this.rows * this.cellHeight - 78
        );
    }
}

class Key {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.radius = 10;
        this.collected = false;
    }

    draw() {
        if (this.collected) return;

        ctx.fillStyle = "orange";
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
        ctx.fill();

        // little highlight
        ctx.fillStyle = "white";
        ctx.beginPath();
        ctx.arc(this.x - 3, this.y - 3, 3, 0, Math.PI * 2);
        ctx.fill();
    }
}




// =====================
// Game Setup
// =====================
const player = new Player(canvas.width / 2, canvas.height / 2);
const bullets = [];
const enemies = [];
const walls = [];
const levelKeys = [];
const slotMachine = new SlotMachine(1, 2); // 1 column, 2 rows for now

const SLOT_MACHINE_LIMITS = {
    maxRows: 5,
    maxCols: 5
};

let rowUpgradeCost = 10;
let colUpgradeCost = 20;
const upgradeCostMultiplier = 1.5;

const slotUpgradeButtons = {
    rows: { x: 300, y: 210, w: 160, h: 35 },
    cols: { x: 300 + 180, y: 210, w: 160, h: 35 }
};

let currentLevelIndex = 0;
let door;
let lastTime = 0;
let gameState = "title";
let readyForNextLevel = false;
let collectedKeys = 0;
let totalKeys = 0;


canvas.addEventListener("mousedown", () => {
    if (gameState === "title") {
        currentLevelIndex = 0;
        loadLevel(currentLevelIndex);
        setGameState("playing");
    }
});

canvas.addEventListener("mousedown", (e) => {
    const rect = canvas.getBoundingClientRect();
    const mx = e.clientX - rect.left;
    const my = e.clientY - rect.top;

    if (gameState === "transition") {
        slotMachine.handleClick(mx, my);
        slotMachine.handleButtonClick(mx, my);
        handleSlotUpgradeButtons(mx, my);
    }
});

const EnemyTypes = {
    basic: {
        name: "Basic",
        bodyColor: "red",
        barrelColor: "darkred",
        radius: 14,
        speed: 1.2,
        health: 40,
        damage: 8,
        fireRate: 500,
        range: 250,
        coinReward: 5
    },

    scout: {
        name: "Scout",
        bodyColor: "#00ff88",
        barrelColor: "#00cc55",
        radius: 10,
        speed: 2.0,
        health: 25,
        damage: 3,
        fireRate: 300,     // fires often but weak
        range: 180,
        coinReward: 3
    },

    sniper: {
        name: "Sniper",
        bodyColor: "#aa66ff",
        barrelColor: "#7733cc",
        radius: 16,
        speed: 0.4,
        health: 35,
        damage: 25,
        fireRate: 1000,    // slow firing
        range: 500,
        coinReward: 8
    },

    tank: {
        name: "Tank",
        bodyColor: "#ffaa00",
        barrelColor: "#cc7700",
        radius: 25,
        speed: 0.8,
        health: 300,
        damage: 10,
        fireRate: 400,
        range: 1000,
        coinReward: 15
    }
};


const levels = [
    {
        playerStart: { x: 50, y: 150 },
        completionType: "keys",
        walls: [
            { x: 0, y: 0, w: canvas.width, h: 10 },
            { x: 0, y: 0, w: 10, h: canvas.height },
            { x: canvas.width - 10, y: 0, w: 10, h: canvas.height },
            { x: 0, y: canvas.height - 10, w: canvas.width, h: 10 },
            { x: 0, y: canvas.height / 3, w: canvas.width * 0.75, h: 20 },
            { x: canvas.width * 0.5, y: canvas.height * 2 / 3, w: canvas.width * 0.5, h: 20 },
            { x: canvas.width * 0.25, y: canvas.height * 2 / 3, w: 20, h: canvas.height / 3 },
            { x: canvas.width * 0.25, y: canvas.height / 3, w: 20, h: 50 }
        ],
        enemies: [
            { x: canvas.width - 100, y: 100 },
            { x: canvas.width - 100, y: canvas.height - 150 },
            { x: 50, y: canvas.height * 0.5, type: "scout" },
            { x: canvas.width * 0.5, y: canvas.height * 0.5, type: "scout" }
        ],
        keys: [
            { x: 100, y: canvas.height - 50 }
        ],
        door: { x: canvas.width - 50, y: canvas.height - 180, w: 40, h: 170 }
    },

    {
        playerStart: { x: 50, y: canvas.height / 2 },
        completionType: "keys",
        walls: [
            { x: 0, y: 0, w: canvas.width, h: 10 },
            { x: 0, y: 0, w: 10, h: canvas.height },
            { x: canvas.width - 10, y: 0, w: 10, h: canvas.height },
            { x: 0, y: canvas.height - 10, w: canvas.width, h: 10 },
            { x: 0, y: canvas.height / 3, w: canvas.width / 3, h: 20 },
            { x: 0, y: canvas.height * 2 / 3, w: canvas.width / 4, h: 20 },
            { x: canvas.width / 3, y: canvas.height * 2 / 3, w: canvas.width / 3, h: 20 },
            { x: canvas.width * 0.75, y: canvas.height * 2 / 3, w: canvas.width / 4, h: 20 },
            { x: canvas.width / 3, y: canvas.height * 2 / 3, w: 20, h: 50 },
            { x: canvas.width / 2, y: canvas.height / 3, w: canvas.height / 2, h: 20 },
            { x: canvas.width / 2, y: canvas.height / 3 - 50, w: 20, h: 50 },
            { x: canvas.width * 0.75, y: 0, w: 20, h: canvas.height / 3 },
        ],
        enemies: [
            { x: 500, y: 150 },
            { x: 100, y: 500 },
            { x: 100, y: 100, type: "sniper" },
            { x: 700, y: 100, type: "sniper" },
            { x: 400, y: 500, type: "scout" },
        ],
        keys: [
            { x: 50, y: 100 },
            { x: 700, y: 550 }
        ],
        door: { x: 620, y: 10, w: 170, h: 40 }
    },

    {
        playerStart: { x: 400, y: 400 },
        completionType: "keys",
        walls: [
            { x: 0, y: 0, w: canvas.width, h: 10 },
            { x: 0, y: 0, w: 10, h: canvas.height },
            { x: canvas.width - 10, y: 0, w: 10, h: canvas.height },
            { x: 0, y: canvas.height - 10, w: canvas.width, h: 10 },
            { x: 160, y: 150, w: 20, h: 640 },
            { x: 320, y: 450, w: 480, h: 20 },
            { x: 320, y: 0, w: 20, h: 300 },
            { x: 320, y: 300, w: 180, h: 20 },
            { x: 480, y: 150, w: 20, h: 150 },
            { x: 480, y: 150, w: 160, h: 20 },
            { x: 640, y: 150, w: 20, h: 150 },
        ],
        enemies: [
            { x: 250, y: 100 },
            { x: 250, y: 200 },
            { x: 550, y: 200 },
            { x: 400, y: 200, type: "scout" },
            { x: 550, y: 100, type: "scout" },
            { x: 100, y: 300, type: "scout" },
            { x: 100, y: 450, type: "sniper" },
            { x: 700, y: 500, type: "sniper" },
        ],
        keys: [
            { x: 400, y: 100 },
            { x: 300, y: 550 }
        ],
        door: { x: 10, y: 550, w: 150, h: 40 }
    },

    {
        playerStart: { x: 75, y: 75 },
        completionType: "enemies",
        walls: [
            { x: 0, y: 0, w: canvas.width, h: 10 },
            { x: 0, y: 0, w: 10, h: canvas.height },
            { x: canvas.width - 10, y: 0, w: 10, h: canvas.height },
            { x: 0, y: canvas.height - 10, w: canvas.width, h: 10 },
            { x: 150, y: 0, w: 20, h: 500 },
            { x: 650, y: 100, w: 20, h: 500 },
        ],
        enemies: [
            { x: 400, y: 100 },
            { x: 200, y: 300 },
            { x: 600, y: 300 },
            { x: 400, y: 500 },
            { x: 200, y: 100, type: "scout" },
            { x: 600, y: 500, type: "scout" },
            { x: 200, y: 500, type: "sniper" },
            { x: 600, y: 100, type: "sniper" },
            { x: 400, y: 300, type: "tank" }
        ],
        keys: [],
        door: { x: 670, y: 550, w: 120, h: 40 }
    }
];

loadLevel(currentLevelIndex);

const upgradePool = [
    // COMMON
    {
        name: "Heal 25 HP",
        cost: 0,
        apply: (player) => {
            player.stats.health = Math.min(player.stats.maxHealth, player.stats.health + 25);
        }
    },
    {
        name: "Max Health +15",
        cost: 0,
        apply: (player) => {
            player.stats.maxHealth += 15;
        }
    },
    {
        name: "Damage +1",
        cost: 0,
        apply: (player) => {
            player.stats.damage += 1;
        }
    },
    {
        name: "Speed +0.3",
        cost: 0,
        apply: (player) => {
            player.stats.speed += 0.3;
        }
    },
    {
        name: "Range +40",
        cost: 0,
        apply: (player) => {
            player.stats.range += 40;
        }
    },
    {
        name: "Fire Rate -30ms",
        cost: 0,
        apply: (player) => {
            player.stats.fireRate = Math.max(50, player.stats.fireRate - 30);
        }
    },
    {
        name: "Heal 25 HP",
        cost: 0,
        apply: (player) => {
            player.stats.health = Math.min(player.stats.maxHealth, player.stats.health + 25);
        }
    },
    {
        name: "Max Health +15",
        cost: 0,
        apply: (player) => {
            player.stats.maxHealth += 15;
        }
    },
    {
        name: "Damage +1",
        cost: 0,
        apply: (player) => {
            player.stats.damage += 1;
        }
    },
    {
        name: "Speed +0.3",
        cost: 0,
        apply: (player) => {
            player.stats.speed += 0.3;
        }
    },
    {
        name: "Range +40",
        cost: 0,
        apply: (player) => {
            player.stats.range += 40;
        }
    },
    {
        name: "Fire Rate -30ms",
        cost: 0,
        apply: (player) => {
            player.stats.fireRate = Math.max(50, player.stats.fireRate - 30);
        }
    },
    {
        name: "Heal 25 HP",
        cost: 0,
        apply: (player) => {
            player.stats.health = Math.min(player.stats.maxHealth, player.stats.health + 25);
        }
    },
    {
        name: "Max Health +15",
        cost: 0,
        apply: (player) => {
            player.stats.maxHealth += 15;
        }
    },
    {
        name: "Damage +1",
        cost: 0,
        apply: (player) => {
            player.stats.damage += 1;
        }
    },
    {
        name: "Speed +0.3",
        cost: 0,
        apply: (player) => {
            player.stats.speed += 0.3;
        }
    },
    {
        name: "Range +40",
        cost: 0,
        apply: (player) => {
            player.stats.range += 40;
        }
    },
    {
        name: "Fire Rate -30ms",
        cost: 0,
        apply: (player) => {
            player.stats.fireRate = Math.max(50, player.stats.fireRate - 30);
        }
    },
    // UNCOMMON
    {
        name: "Heal 40 HP",
        cost: 0,
        apply: (player) => {
            player.stats.health = Math.min(player.stats.maxHealth, player.stats.health + 40);
        }
    },
    {
        name: "Max Health +25",
        cost: 0,
        apply: (player) => {
            player.stats.maxHealth += 25;
        }
    },
    {
        name: "Damage +1.5",
        cost: 0,
        apply: (player) => {
            player.stats.damage += 1.5;
        }
    },
    {
        name: "Speed +0.5",
        cost: 0,
        apply: (player) => {
            player.stats.speed += 0.5;
        }
    },
    {
        name: "Range +60",
        cost: 0,
        apply: (player) => {
            player.stats.range += 60;
        }
    },
    {
        name: "Fire Rate -50ms",
        cost: 0,
        apply: (player) => {
            player.stats.fireRate = Math.max(50, player.stats.fireRate - 50);
        }
    },
    {
        name: "Heal 40 HP",
        cost: 0,
        apply: (player) => {
            player.stats.health = Math.min(player.stats.maxHealth, player.stats.health + 40);
        }
    },
    {
        name: "Max Health +25",
        cost: 0,
        apply: (player) => {
            player.stats.maxHealth += 25;
        }
    },
    {
        name: "Damage +1.5",
        cost: 0,
        apply: (player) => {
            player.stats.damage += 1.5;
        }
    },
    {
        name: "Speed +0.5",
        cost: 0,
        apply: (player) => {
            player.stats.speed += 0.5;
        }
    },
    {
        name: "Range +60",
        cost: 0,
        apply: (player) => {
            player.stats.range += 60;
        }
    },
    {
        name: "Fire Rate -50ms",
        cost: 0,
        apply: (player) => {
            player.stats.fireRate = Math.max(50, player.stats.fireRate - 50);
        }
    },
    // RARE
    {
        name: "Heal 60 HP",
        cost: 0,
        apply: (player) => {
            player.stats.health = Math.min(player.stats.maxHealth, player.stats.health + 60);
        }
    },
    {
        name: "Max Health +40",
        cost: 0,
        apply: (player) => {
            player.stats.maxHealth += 40;
        }
    },
    {
        name: "Damage +2",
        cost: 0,
        apply: (player) => {
            player.stats.damage += 2;
        }
    },
    {
        name: "Speed +0.7",
        cost: 0,
        apply: (player) => {
            player.stats.speed += 0.7;
        }
    },
    {
        name: "Range +90",
        cost: 0,
        apply: (player) => {
            player.stats.range += 90;
        }
    },
    {
        name: "Fire Rate -70ms",
        cost: 0,
        apply: (player) => {
            player.stats.fireRate = Math.max(50, player.stats.fireRate - 70);
        }
    }
];


// =====================
// Game Loop
// =====================
function gameLoop(timestamp) {
    const deltaTime = timestamp - lastTime;
    lastTime = timestamp;

    update(deltaTime);
    draw();

    requestAnimationFrame(gameLoop);
}

function update(deltaTime) {
    if (gameState === "playing") {
        player.update(deltaTime);

        checkKeyPickup();

        // Enemies
        for (let i = enemies.length - 1; i >= 0; i--) {
            const enemy = enemies[i];
            enemy.update(player);

            // Enemy touching player (contact damage)
            if (circleCollision(enemy, player)) {
                player.stats.health -= 0.1; // slow damage over time
                if (player.stats.health <= 0) {
                    setGameState("defeat");
                }
            }
        }

        if (currentLevelCompletionType === "enemies") {
            door.locked = enemies.length !== 0;
        }
        else if (currentLevelCompletionType === "keys") {
            door.locked = collectedKeys < totalKeys;
        }

        // Bullets
        for (let i = bullets.length - 1; i >= 0; i--) {
            const bullet = bullets[i];
            bullet.update();

            // Bullet hits wall
            let hitWall = false;
            for (let w of walls) {
                if (circleRectCollision(bullet, w)) {
                    bullets.splice(i, 1);
                    hitWall = true;
                    break;
                }
            }
            if (hitWall) continue;

            let hit = false;

            if (bullet.owner === "player") {
                // Check against enemies
                for (let j = enemies.length - 1; j >= 0; j--) {
                    const enemy = enemies[j];
                    if (circleCollision(bullet, enemy)) {
                        enemy.stats.health -= bullet.damage;
                        bullets.splice(i, 1);
                        hit = true;

                        if (enemy.stats.health <= 0) {
                            // Award coins to player
                            player.coins += enemy.coinValue;

                            // Remove enemy
                            enemies.splice(j, 1);
                        }
                        break;
                    }
                }
            } else {
                // Enemy bullet -> player
                if (circleCollision(bullet, player)) {
                    player.stats.health -= bullet.damage;
                    bullets.splice(i, 1);
                    hit = true;

                    if (player.stats.health <= 0) {
                        setGameState("defeat");
                    }
                }
            }

            if (!hit && bullet.isOutOfRange()) {
                bullets.splice(i, 1);
            }
        }

        if (!door.locked && circleRectCollision(player, door)) {
            if (currentLevelIndex < levels.length - 1) {
                setGameState("transition");
                readyForNextLevel = true; // indicate player can now upgrade / move on
                currentLevelIndex++;
            } else {
                setGameState("victory");
            }
        }

    }

}

function draw() {
    if (gameState === "title") {
        drawTitleScreen();
    }
    else if (gameState === "playing") {
        drawGame();
    }
    else if (gameState === "transition") {
        drawTransitionScreen();
    }
    else if (gameState === "victory") {
        drawVictoryScreen();
    }
    else if (gameState === "defeat") {
        drawDefeatScreen();
    }
}

function drawGame() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    walls.forEach(w => w.draw());
    levelKeys.forEach(k => k.draw());
    door.draw();
    player.draw();
    enemies.forEach(e => e.draw());
    bullets.forEach(b => b.draw());

    // Stats panel
    drawPlayerStatsUI(20, 30);
    drawCoinsUI();
    drawKeysUI();

    // Level text
    ctx.fillStyle = "white";
    ctx.font = "16px sans-serif";
    ctx.textAlign = "left";
    ctx.fillText(`Level ${currentLevelIndex + 1}`, 20, canvas.height - 20);
}


function drawTitleScreen() {
    ctx.fillStyle = "black";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = "yellow";
    ctx.font = "48px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("SLOT SHOOTERS", canvas.width / 2, canvas.height / 2 - 40);

    ctx.fillStyle = "white";
    ctx.font = "24px sans-serif";
    ctx.fillText("Click to Start", canvas.width / 2, canvas.height / 2 + 40);

    ctx.font = "20px sans-serif";
    ctx.fillText("Instructions: use W,A,S,D to move, click to shoot.", canvas.width / 2, canvas.height / 2 + 200);
}

function drawTransitionScreen() {
    ctx.fillStyle = "#111";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = "white";
    ctx.font = "36px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(`Level ${currentLevelIndex} Complete!`, canvas.width / 2, 80);

    ctx.font = "18px sans-serif";
    ctx.fillText("Spend coins to spin or upgrade the slot machine!", canvas.width / 2, 100);

    ctx.textAlign = "left";
    drawPlayerStatsUI(40, 400);
    drawCoinsUI();

    slotMachine.draw();
    slotMachine.drawNextLevelButton();
    drawSlotUpgradeButtons();
}


function drawVictoryScreen() {
    ctx.fillStyle = "#000";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.fillStyle = "gold";
    ctx.font = "48px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("VICTORY!", canvas.width / 2, canvas.height / 2 - 40);

    ctx.font = "24px sans-serif";
    ctx.fillStyle = "white";
    ctx.fillText("You completed all levels!", canvas.width / 2, canvas.height / 2 + 20);
    ctx.fillText("Refresh to play again", canvas.width / 2, canvas.height / 2 + 60);
}

function drawDefeatScreen() {
    ctx.fillStyle = "#120000";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    ctx.textAlign = "center";

    ctx.fillStyle = "red";
    ctx.font = "64px sans-serif";
    ctx.fillText("DEFEAT", canvas.width / 2, canvas.height / 2 - 40);

    ctx.fillStyle = "white";
    ctx.font = "20px sans-serif";
    ctx.fillText(
        "Your tank was destroyed",
        canvas.width / 2,
        canvas.height / 2 + 10
    );

    ctx.fillText(
        "Refresh to return to the Title Screen",
        canvas.width / 2,
        canvas.height / 2 + 50
    );
}


function drawPlayerStatsUI(x, y) {
    const s = player.stats;
    const lineHeight = 18;

    // Background panel
    ctx.fillStyle = "rgba(0,0,0,0.4)";
    ctx.fillRect(x - 10, y - 20, 160, 100);

    ctx.fillStyle = "white";
    ctx.font = "14px monospace";
    ctx.textAlign = "left";

    let line = 0;

    ctx.fillText(`HP: ${Math.floor(s.health)} / ${s.maxHealth}`, x, y + line++ * lineHeight);
    ctx.fillText(`Damage: ${s.damage}`, x, y + line++ * lineHeight);
    ctx.fillText(`Speed: ${s.speed.toFixed(2)}`, x, y + line++ * lineHeight);
    ctx.fillText(`Range: ${s.range}`, x, y + line++ * lineHeight);
    ctx.fillText(`Fire Rate: ${s.fireRate} ms`, x, y + line++ * lineHeight);
}

function drawCoinsUI() {
    const padding = 10;
    const x = canvas.width - 110;
    const y = 10;

    // Background
    ctx.fillStyle = "rgba(0,0,0,0.4)";
    ctx.fillRect(x, y, 100, 30);

    // Text
    ctx.fillStyle = "gold";
    ctx.font = "16px monospace";
    ctx.textAlign = "right";
    ctx.fillText(`Coins: ${player.coins}`, x + 100 - padding, y + 20);
}

function drawKeysUI() {
    if (currentLevelCompletionType !== "keys") return;
    const padding = 10;
    const x = canvas.width - 110;
    const y = 30;

    // Background
    ctx.fillStyle = "rgba(0,0,0,0.4)";
    ctx.fillRect(x - 20, y, 120, 30);

    // Text
    ctx.fillStyle = "orange";
    ctx.font = "16px monospace";
    ctx.textAlign = "right";
    ctx.fillText(`Keys: ${collectedKeys} / ${totalKeys}`, x + 100 - padding, y + 20);
}

function drawSlotUpgradeButtons() {
    ctx.font = "14px sans-serif";
    ctx.textAlign = "center";

    // Rows button
    ctx.fillStyle = slotMachine.rows >= SLOT_MACHINE_LIMITS.maxRows ? "#555" : "gold";
    ctx.fillRect(
        slotUpgradeButtons.rows.x,
        slotUpgradeButtons.rows.y,
        slotUpgradeButtons.rows.w,
        slotUpgradeButtons.rows.h
    );
    ctx.fillStyle = "black";
    ctx.fillText(
        slotMachine.rows >= SLOT_MACHINE_LIMITS.maxRows
            ? "Rows MAX"
            : `+ Row (${Math.floor(rowUpgradeCost)}c)`,
        slotUpgradeButtons.rows.x + slotUpgradeButtons.rows.w / 2,
        slotUpgradeButtons.rows.y + 23
    );

    // Columns button
    ctx.fillStyle = slotMachine.columns >= SLOT_MACHINE_LIMITS.maxCols ? "#555" : "gold";
    ctx.fillRect(
        slotUpgradeButtons.cols.x,
        slotUpgradeButtons.cols.y,
        slotUpgradeButtons.cols.w,
        slotUpgradeButtons.cols.h
    );
    ctx.fillStyle = "black";
    ctx.fillText(
        slotMachine.columns >= SLOT_MACHINE_LIMITS.maxCols
            ? "Cols MAX"
            : `+ Col (${Math.floor(colUpgradeCost)}c)`,
        slotUpgradeButtons.cols.x + slotUpgradeButtons.cols.w / 2,
        slotUpgradeButtons.cols.y + 23
    );
}

function handleSlotUpgradeButtons(mx, my) {
    if (!slotMachine.isEmpty) return;
    // Upgrade Rows
    const r = slotUpgradeButtons.rows;
    if (
        mx >= r.x && mx <= r.x + r.w &&
        my >= r.y && my <= r.y + r.h
    ) {
        if (
            slotMachine.rows < SLOT_MACHINE_LIMITS.maxRows &&
            player.coins >= rowUpgradeCost
        ) {
            player.coins -= rowUpgradeCost;
            slotMachine.resize(slotMachine.columns, slotMachine.rows + 1);
            rowUpgradeCost = Math.ceil(rowUpgradeCost * upgradeCostMultiplier);
        }
    }

    // Upgrade Columns
    const c = slotUpgradeButtons.cols;
    if (
        mx >= c.x && mx <= c.x + c.w &&
        my >= c.y && my <= c.y + c.h
    ) {
        if (
            slotMachine.columns < SLOT_MACHINE_LIMITS.maxCols &&
            player.coins >= colUpgradeCost
        ) {
            player.coins -= colUpgradeCost;
            slotMachine.resize(slotMachine.columns + 1, slotMachine.rows);
            colUpgradeCost = Math.ceil(colUpgradeCost * upgradeCostMultiplier);
        }
    }
}


function setGameState(state) {
    gameState = state;
}


function circleCollision(a, b) {
    const dx = a.x - b.x;
    const dy = a.y - b.y;
    const dist = Math.hypot(dx, dy);
    return dist < a.radius + b.radius;
}

function circleRectCollision(circle, rect) {
    const closestX = Math.max(rect.x, Math.min(circle.x, rect.x + rect.width));
    const closestY = Math.max(rect.y, Math.min(circle.y, rect.y + rect.height));

    const dx = circle.x - closestX;
    const dy = circle.y - closestY;

    return (dx * dx + dy * dy) < (circle.radius * circle.radius);
}

function moveWithWallCollision(entity, dx, dy) {
    // Try X movement
    entity.x += dx;
    for (let wall of walls) {
        if (circleRectCollision(entity, wall)) {
            entity.x -= dx;
            break;
        }
    }

    // Try Y movement
    entity.y += dy;
    for (let wall of walls) {
        if (circleRectCollision(entity, wall)) {
            entity.y -= dy;
            break;
        }
    }
}

function checkKeyPickup() {
    for (const key of levelKeys) {
        if (key.collected) continue;

        const dx = player.x - key.x;
        const dy = player.y - key.y;
        const dist = Math.hypot(dx, dy);

        if (dist < player.radius + key.radius) {
            key.collected = true;
            collectedKeys++;
        }
    }
}


function loadLevel(index) {
    const level = levels[index];

    // Clear old entities
    walls.length = 0;
    enemies.length = 0;
    bullets.length = 0;

    // Create walls
    for (let w of level.walls) {
        walls.push(new Wall(w.x, w.y, w.w, w.h));
    }

    // Create enemies
    for (let e of level.enemies) {
        enemies.push(new Enemy(e.x, e.y, e.type));
    }

    // Create door
    const d = level.door;
    door = new Door(d.x, d.y, d.w, d.h);

    // Keys
    if (level.keys) {
        levelKeys.length = 0;
        for (const k of level.keys) {
            levelKeys.push(new Key(k.x, k.y));
        }
    }
    collectedKeys = 0;
    totalKeys = level.keys.length;

    // Set player start position for this level
    player.x = level.playerStart.x;
    player.y = level.playerStart.y;

    currentLevelCompletionType = level.completionType || "enemies";

}


// Start game
requestAnimationFrame(gameLoop);
