const config = {
    type: Phaser.AUTO,
    width: 800,
    height: 600,
    backgroundColor: "#222",
    scene: {
        preload,
        create
    }
};

const game = new Phaser.Game(config);

let player;
let enemies = [];
let currentTurn = "player";
let infoText;
let playerText;
let enemyTexts = [];
let selectedEnemyIndex = 0;
let skillButtons = [];
let skillDescriptionText;

const skills = [
    {
        name: "Attack",
        mpCost: 0,
        power: 5,
        color: "#ffffff",
        description: "Deal 5 damage to a single target.",
        targetType: "single"
    },
    {
        name: "Shield Bash",
        mpCost: 4,
        power: 7,
        color: "#cccccc",
        description: "Deal 7 damage to a single target. If you're in DEFENSIVE stance, deal 12 damage instead and switch to OFFENSIVE stance.",
        targetType: "single"
    },
    {
        name: "Drain Slash",
        mpCost: 7,
        power: 6,
        color: "#55ff00",
        description: "Deal 6 damage to a single target and heal equal to the damage dealt. If you're in OFFENSIVE stance, switch to HEALTHY stance.",
        targetType: "single"
    },
    {
        name: "Assault",
        mpCost: 12,
        power: 10,
        color: "#ff3333",
        description: "Deal 10 damage to all enemies, but take 5 recoil damage unless you're in DEFENSIVE stance. If you're in OFFENSIVE stance, deal 20 damage instead but take 10 recoil damage.",
        targetType: "aoe"
    },
    {
        name: "Dispel",
        mpCost: 5,
        power: 0,
        color: "#ffffaa",
        description: "Switch all enemies to NEUTRAL stance.",
        targetType: "aoe"
    },
    {
        name: "Rest",
        mpCost: 0,
        power: 0,
        color: "#0099ff",
        description: "Recover 10 MP. If you're in HEALTHY stance, recover 15 MP instead.",
        targetType: "self"
    },
    {
        name: "Heal",
        mpCost: 6,
        power: -10,            // negative = healing
        color: "#00ff00",
        description: "Heal 10 HP. Then if your HP is less than half your max HP, switch to DEFENSIVE stance.",
        targetType: "self"
    },
    {
        name: "Cursed Bolt",
        mpCost: 8,
        power: 8,
        color: "#ee44dd",
        description: "Deal 8 damage to a single target and switch them to CURSED stance.",
        targetType: "single"
    },
    {
        name: "Blizzard",
        mpCost: 15,
        power: 7,
        color: "#2266ff",
        description: "Deal 7 damage to all enemies. For each target in OFFENSIVE stance, deal 15 damage instead and switch them to NEUTRAL stance.",
        targetType: "aoe"
    },
    {
        name: "Rage Strike",
        mpCost: 20,
        power: 15,
        color: "#aa0088",
        description: "Deal 15 damage to a single target. If in CURSED stance, deal 20 damage instead and switch to NEUTRAL stance. Otherwise, switch to CURSED stance.",
        targetType: "single",
    },
    {
        name: "NEUTRAL Stance",
        mpCost: 0,
        color: "#ffffff",
        description: "Return to NEUTRAL stance.",
        type: "stance",
        stance: "neutral"
    },
    {
        name: "OFFENSIVE Stance",
        mpCost: 0,
        color: "#ff4444",
        description: "Switch to OFFENSIVE stance (+30% damage).",
        type: "stance",
        stance: "offensive"
    },
    {
        name: "DEFENSIVE Stance",
        mpCost: 0,
        color: "#44ffff",
        description: "Switch to DEFENSIVE stance (-30% damage taken).",
        type: "stance",
        stance: "defensive"
    },
    {
        name: "HEALTHY Stance",
        mpCost: 0,
        color: "#44ff44",
        description: "Switch to HEALTHY stance (regen 5 HP per turn).",
        type: "stance",
        stance: "healthy"
    },
    {
        name: "CURSED Stance",
        mpCost: 0,
        color: "#dd00dd",
        description: "Switch to CURSED stance (-20% damage, +20% damage taken).",
        type: "stance",
        stance: "cursed"
    }
];

const enemySkills = {
    orc: [
        {
            name: "OFFENSIVE Stance",
            power: 0,
            description: "Switch to OFFENSIVE stance (+30% damage).",
            targetType: "self",
            type: "stance",
            stance: "offensive"
        },
        {
            name: "Guarding Slash",
            power: 4,
            description: "Attacks and switches to DEFENSIVE stance.",
            targetType: "single"
        },
        {
            name: "Great Smash",
            power: 10,
            description: "A super powerful attack.",
            targetType: "single"
        }
    ],
    mage: [
        {
            name: "Lightning Strike",
            power: 8,
            description: "A powerful lightning strike.",
            targetType: "single"
        },
        {
            name: "Cursed Orb",
            power: 3,
            description: "A bolt of dark energy.",
            targetType: "single"
        },
        {
            name: "Heal All",
            power: -5,
            description: "Heals all enemies.",
            targetType: "group"
        },
        {
            name: "HEALTHY Stance",
            power: 0,
            description: "Switch to HEALTHY stance (regen 5 HP per turn).",
            targetType: "self",
            type: "stance",
            stance: "healthy"
        }
    ],
    dragon: [
        {
            name: "Tail Whip",
            power: 9,
            description: "A powerful tail strike.",
            targetType: "single"
        },
        {
            name: "Draining Bite",
            power: 6,
            description: "Attacks the player and heals the dragon.",
            targetType: "single"
        },
        {
            name: "Purging Flames",
            power: 5,
            description: "A burst of fire that resets the player to NEUTRAL stance.",
            targetType: "single"
        },
        {
            name: "OFFENSIVE Stance",
            power: 0,
            description: "Switch to OFFENSIVE stance (+30% damage).",
            targetType: "self",
            type: "stance",
            stance: "offensive"
        },
        {
            name: "DEFENSIVE Stance",
            power: 0,
            description: "Switch to DEFENSIVE stance (-30% damage taken).",
            targetType: "self",
            type: "stance",
            stance: "defensive"
        },
    ]
};

const stances = {
    neutral: {
        name: "NEUTRAL",
        description: "No special effects.",
        damageDealtMultiplier: 1.0,
        damageTakenMultiplier: 1.0,
        healPerTurn: 0
    },
    offensive: {
        name: "OFFENSIVE",
        description: "Deal 30% more damage.",
        damageDealtMultiplier: 1.3,
        damageTakenMultiplier: 1.0,
        healPerTurn: 0
    },
    defensive: {
        name: "DEFENSIVE",
        description: "Take 30% less damage.",
        damageDealtMultiplier: 1.0,
        damageTakenMultiplier: 0.7,
        healPerTurn: 0
    },
    healthy: {
        name: "HEALTHY",
        description: "Recover 5 HP at the start of each turn.",
        damageDealtMultiplier: 1.0,
        damageTakenMultiplier: 1.0,
        healPerTurn: 5
    },
    cursed: {
        name: "CURSED",
        description: "Deal 20% less damage and take 20% more damage.",
        damageDealtMultiplier: 0.8,
        damageTakenMultiplier: 1.2,
        healPerTurn: 0
    }
};


function preload() { }

function create() {
    // Player
    player = {
        name: "Hero",
        hp: 100,
        maxHp: 100,
        mp: 50,
        maxMp: 50,
        stance: "neutral"
    };

    // Enemies
    enemies = [
        {
            name: "Angry Orc",
            hp: 80,
            maxHp: 80,
            skills: enemySkills.orc,
            stance: "neutral"
        },
        {
            name: "Dragon",
            hp: 120,
            maxHp: 120,
            skills: enemySkills.dragon,
            stance: "neutral"
        },
        {
            name: "Dark Mage",
            hp: 70,
            maxHp: 70,
            skills: enemySkills.mage,
            stance: "neutral"
        }
    ];


    // Player HP UI
    playerText = this.add.text(50, 100, "", {
        fontSize: "22px",
        fill: "#00ff00"
    });

    // Enemy HP UI (clickable for targeting)
    enemyTexts = [];
    enemies.forEach((enemy, index) => {
        const text = this.add.text(500, 80 + index * 80, "", {
            fontSize: "20px",
            fill: "#ff4444"
        })
            .setInteractive()
            .on("pointerdown", () => {
                if (currentTurn === "player" && enemies[index].hp > 0) {
                    selectedEnemyIndex = index;
                    infoText.setText(`Target selected: ${enemies[index].name}`);
                    updateUI();
                }
            });

        enemyTexts.push(text);
    });

    // Info text
    infoText = this.add.text(100, 350, "", {
        fontSize: "24px",
        fill: "#ffff00",
        wordWrap: { width: 650 }
    });

    // Skill description box
    skillDescriptionText = this.add.text(100, 200, "", {
        fontSize: "18px",
        fill: "#ffffff",
        backgroundColor: "#000000",
        padding: { x: 8, y: 6 },
        wordWrap: { width: 250 }
    });
    skillDescriptionText.setVisible(false);

    createSkillButtons.call(this);
    updateUI();
    infoText.setText("Your turn! Choose a target, then a skill.");

    updateUI();
    infoText.setText("Your turn! Click an enemy to select a target.");
}

function createSkillButtons() {
    const startX = 30;
    const startY = 450;
    const spacing = 30;

    skills.forEach((skill, index) => {
        const btn = this.add.text(
            (startX + 265 * Math.floor(index / 5)),
            (startY + (index % 5) * spacing),
            (skill.type === "stance" ? `[ ${skill.name} ]` : `[ ${skill.name} (${skill.mpCost} MP) ]`),
            {
                fontSize: "18px",
                fill: skill.color
            }
        )
            .setInteractive()

            // Click = use skill
            .on("pointerdown", () => {
                if (currentTurn === "player") {
                    useSkill(skill);
                }
            })

            // Hover = show description
            .on("pointerover", () => {
                skillDescriptionText.setText(
                    `${skill.name}\nCost: ${skill.mpCost} MP\n${skill.description}`
                );
                skillDescriptionText.setVisible(true);
            })

            // Mouse leaves = clear description
            .on("pointerout", () => {
                skillDescriptionText.setText("");
                skillDescriptionText.setVisible(false);
            });

        skillButtons.push(btn);
    });
}

function updateUI() {
    playerText.setText(
        `${player.name}
HP: ${player.hp}/${player.maxHp}
MP: ${player.mp}/${player.maxMp}
Stance: ${stances[player.stance].name}`
    );

    enemies.forEach((enemy, index) => {
        let status = (enemy.hp > 0
            ? `HP: ${enemy.hp} / ${enemy.maxHp}`
            : `DEFEATED`)
            + `\nStance: ${stances[enemy.stance].name}`;

        let isSelected = index === selectedEnemyIndex && enemy.hp > 0;
        let color = isSelected ? "#ffff00" : "#ff4444";

        enemyTexts[index].setColor(color);
        enemyTexts[index].setText(
            `${enemy.name}\n${status}`
        );
    });
}

function useSkill(skill) {
    if (skill.type === "stance") {
        if (player.stance !== skill.stance) {
            changeStance(player, skill.stance);
        }
        return;
    }

    if (player.mp < skill.mpCost) {
        infoText.setText("Not enough MP!");
        return;
    }

    player.mp -= skill.mpCost;

    switch (skill.targetType) {
        case "single":
            useSingleTargetSkill(skill);
            break;

        case "aoe":
            useAOESkill(skill);
            break;

        case "random":
            useRandomTargetSkill(skill);
            break;

        case "self":
            useSelfTargetSkill(skill);
            break;
    }

    updateUI();

    // Victory check (only matters if enemies are involved)
    const anyAlive = enemies.some(e => e.hp > 0);
    if (!anyAlive && skill.targetType !== "self") {
        infoText.setText("All enemies defeated! You win!");
        currentTurn = "none";
        return;
    }

    currentTurn = "enemy";
    setTimeout(enemyTurn, 1500);
}

function changeStance(target, newStance) {
    target.stance = newStance;
    infoText.setText(
        `${target.name} changed to ${stances[newStance].name} stance!`
    );

    updateUI();

    currentTurn = "enemy";
    setTimeout(enemyTurn, 1500);
}

function useSingleTargetSkill(skill) {
    const target = enemies[selectedEnemyIndex];

    if (!target || target.hp <= 0) {
        target = enemies.find(e => e.hp > 0);
    }

    let power = applySkillEffectsBefore(skill);
    power = applyEffect(target, power, player);
    applySkillEffectsAfter(skill, power, target);
    infoText.setText(
        `You used ${skill.name} on ${target.name} for ${Math.abs(power)}!`
    );
}

function useAOESkill(skill) {
    let basePower = applySkillEffectsBefore(skill);
    enemies.forEach(enemy => {
        if (enemy.hp > 0) {
            let power = applySkillEffectsDuring(skill, enemy, basePower);
            power = applyEffect(enemy, power, player);
            applySkillEffectsAfter(skill, power, enemy);
        }
    });

    if (skill.name === "Dispel") {
        infoText.setText(
            `You used ${skill.name}! All enemies returned to NEUTRAL stance!`
        );
    } else {
        infoText.setText(
            `You used ${skill.name}! All enemies were hit for ${Math.abs(power)}!`
        );
    }
}

function useRandomTargetSkill(skill) {
    const aliveEnemies = enemies.filter(e => e.hp > 0);

    if (aliveEnemies.length === 0) {
        infoText.setText("No valid targets!");
        player.mp += skill.mpCost;
        return;
    }

    const target =
        aliveEnemies[Math.floor(Math.random() * aliveEnemies.length)];

    let power = applySkillEffectsBefore(skill);
    power = applyEffect(target, power, player);
    applySkillEffectsAfter(skill, power, target);
    infoText.setText(
        `You used ${skill.name} on ${target.name} for ${Math.abs(power)}!`
    );
}

function useSelfTargetSkill(skill) {
    let power = applySkillEffectsBefore(skill);
    power = applyEffect(player, power, player);
    mpPower = applySkillEffectsAfter(skill, power);
    if (skill.name === "Rest") {
        infoText.setText(
            `You used ${skill.name} and restored ${Math.abs(mpPower)} MP!`
        );
    } else {
        infoText.setText(
            `You used ${skill.name} and restored ${Math.abs(power)} HP!`
        );
    }
}

function applySkillEffectsBefore(skill) {
    power = skill.power;
    switch (skill.name) {
        case "Shield Bash":
            if (player.stance === "defensive") {
                power = 12;
            }
            break;
        case "Assault":
            if (player.stance === "offensive") {
                power = 20;
                applyEffect(player, 10);
            } else if (player.stance !== "defensive") {
                applyEffect(player, 5);
            }
            break;
        case "Rage Strike":
            if (player.stance === "cursed") {
                power = 25;
            }
            break;
    }
    return power;
}

function applySkillEffectsDuring(skill, enemy, basePower) {
    switch (skill.name) {
        case "Blizzard":
            if (enemy.stance === "offensive") {
                basePower = 15;
                enemy.stance = "neutral";
            }
            break;
    }
    return basePower;
}

function applySkillEffectsAfter(skill, power, target = null) {
    switch (skill.name) {
        case "Shield Bash":
            if (player.stance === "defensive") {
                player.stance = "offensive";
            }
            break;
        case "Drain Slash":
            applyEffect(player, -power);
            if (player.stance === "offensive") {
                player.stance = "healthy";
            }
            break;
        case "Dispel":
            target.stance = "neutral";
            break;
        case "Rest":
            const mpPower = player.stance === "healthy" ? 15 : 10;
            player.mp = Math.min(player.maxMp, player.mp + mpPower);
            return mpPower;
        case "Heal":
            if (player.hp <= player.maxHp / 2) {
                player.stance = "defensive";
            }
            break;
        case "Cursed Bolt":
            target.stance = "cursed";
            break;
        case "Rage Strike":
            if (player.stance === "cursed") {
                player.stance = "neutral";
            } else {
                player.stance = "cursed";
            }
            break;
        case "Guarding Slash":
            target.stance = "defensive";
            break;
        case "Cursed Orb":
            player.stance = "cursed";
            break;
        case "Draining Bite":
            applyEffect(target, -power);
            target.stance = "healthy";
            break;
        case "Purging Flames":
            if (player.stance !== "cursed") {
                player.stance = "neutral";
            }
            break;
    }
}

function applyEffect(target, power, source = null) {
    let finalPower = power;

    // If this is damage (power > 0), apply stance modifiers
    if (power > 0) {
        if (source) {
            const sourceStance = stances[source.stance];
            finalPower *= sourceStance.damageDealtMultiplier;
        }

        const targetStance = stances[target.stance];
        finalPower *= targetStance.damageTakenMultiplier;
    }

    finalPower = Math.round(finalPower);

    target.hp -= finalPower;

    if (target.hp > target.maxHp) target.hp = target.maxHp;
    if (target.hp < 0) target.hp = 0;
    return finalPower;
}


function enemyTurn() {
    const aliveEnemies = enemies.filter(e => e.hp > 0);
    let index = 0;

    function nextEnemyAction() {
        if (index >= aliveEnemies.length) {
            currentTurn = "player";
            applyStanceStartTurnEffect(player, () => {
                infoText.setText("Your turn!");
            });
            return;
        }

        const enemy = aliveEnemies[index];
        applyStanceStartTurnEffect(enemy, () => {
            // enemy takes their action after stance effect finishes
            const skill = randomFrom(enemy.skills);
            useEnemySkill(enemy, skill);

            if (player.hp <= 0) {
                infoText.setText("You were defeated...");
                currentTurn = "none";
                return;
            }

            index++;
            setTimeout(nextEnemyAction, 1500);
        });
    }

    nextEnemyAction();
}

function randomFrom(array) {
    return array[Math.floor(Math.random() * array.length)];
}

function applyStanceStartTurnEffect(combatant, callback) {
    const stance = stances[combatant.stance];

    if (stance.healPerTurn > 0) {
        combatant.hp += stance.healPerTurn;
        if (combatant.hp > combatant.maxHp) combatant.hp = combatant.maxHp;

        infoText.setText(
            `${combatant.name} recovers ${stance.healPerTurn} HP from Healthy stance!`
        );
        updateUI();
        // Wait before continuing so the message is visible
        setTimeout(() => {
            if (callback) callback();
        }, 1500);
    } else {
        // No stance effect -> continue immediately
        if (callback) callback();
    }
}


function useEnemySkill(enemy, skill) {
    switch (skill.targetType) {
        case "single":
            const power = applyEffect(player, skill.power, enemy);
            applySkillEffectsAfter(skill, skill.power, enemy);
            infoText.setText(
                `${enemy.name} used ${skill.name}! You took ${power} damage.`
            );
            break;

        case "group":
            enemies.forEach(enemy => {
                if (enemy.hp > 0) {
                    applyEffect(enemy, skill.power);
                }
            });
            infoText.setText(
                `${enemy.name} used ${skill.name} and healed all enemies!`
            );
            break;

        case "self":
            if (skill.type === "stance") {
                enemy.stance = skill.stance;
                infoText.setText(
                    `${enemy.name} changed to ${skill.stance} stance!`
                );
                updateUI();
                return;
            }
            applyEffect(enemy, skill.power, enemy);
            infoText.setText(
                `${enemy.name} used ${skill.name} and healed itself!`
            );
            break;
    }

    updateUI();
}

