(() => {

  const {

    Bodies,

    Body,

    Engine,

    Events,

    Mouse,

    MouseConstraint,

    Render,

    Runner,

    World

  } = Matter;



  const scene = document.getElementById("scene");

  const levelIndicatorEl = document.getElementById("levelIndicator");

  const timerEl = document.getElementById("timer");



  const width = 960;

  const height = 540;



  const engine = Engine.create();

  engine.gravity.y = 1.2;

  const { world } = engine;



  const render = Render.create({

    element: scene,

    engine,

    options: {

      width,

      height,

      wireframes: false,

      background: "#05081a",

      pixelRatio: window.devicePixelRatio || 1

    }

  });



  Render.run(render);

  const runner = Runner.create();

  Runner.run(runner, engine);



  const playerCategory = 0x0004;

  const draggableCategory = 0x0002;



  const ground = Bodies.rectangle(width / 2, height - 10, width * 1.2, 40, {

    isStatic: true,

    render: { fillStyle: "#212a4d" }

  });



  const boundaries = [

    Bodies.rectangle(-25, height / 2, 50, height * 2, { isStatic: true, render: { visible: false } }),

    Bodies.rectangle(width + 25, height / 2, 50, height * 2, { isStatic: true, render: { visible: false } }),

    Bodies.rectangle(width / 2, -25, width * 2, 50, { isStatic: true, render: { visible: false } })

  ];



  const playerTexture =

    "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='84' height='120' viewBox='0 0 84 120'><rect width='84' height='120' rx='18' fill='%23fdfcdc'/><rect y='15' width='84' height='12' fill='%23ff9f1c'/><rect y='33' width='84' height='12' fill='%23ff4f87'/><rect y='51' width='84' height='12' fill='%2300f5d4'/><rect y='69' width='84' height='12' fill='%2345dfb1'/><rect y='87' width='84' height='12' fill='%239b5de5'/></svg>";



  const player = Bodies.rectangle(140, height - 200, 46, 66, {

    chamfer: { radius: 12 },

    friction: 0.02,

    frictionAir: 0.045,

    restitution: 0,

    label: "player",

    render: {

      fillStyle: "#fdfcdc",

      strokeStyle: "#00f5d4",

      lineWidth: 3,

      sprite: {

        texture: playerTexture,

        xScale: 46 / 84,

        yScale: 66 / 120

      }

    },

    collisionFilter: { category: playerCategory }

  });



  World.add(world, [ground, ...boundaries, player]);



  const colors = ["#ff6b6b", "#4ecdc4", "#ffd166", "#cdb4db", "#9b5de5"];



  const createCrate = (x, y, size, color) =>

    Bodies.rectangle(x, y, size, size, {

      density: 0.001,

      friction: 0.22,

      restitution: 0.2,

      chamfer: { radius: 6 },

      render: { fillStyle: color },

      collisionFilter: { category: draggableCategory }

    });



  const createOrb = (x, y, radius, color) =>

    Bodies.circle(x, y, radius, {

      density: 0.001,

      frictionAir: 0.01,

      restitution: 0.6,

      render: { fillStyle: color },

      collisionFilter: { category: draggableCategory }

    });



  const createPlatform = ({ x, y, width: w, height: h, angle = 0 }) =>

    Bodies.rectangle(x, y, w, h, {

      isStatic: true,

      angle,

      render: { fillStyle: "#182642" }

    });



  const createExitPortal = ({ x, y, width: w, height: h }) =>

    Bodies.rectangle(x, y, w, h, {

      isStatic: true,

      isSensor: true,

      label: "exit",

      render: {

        fillStyle: "#7cffcb",

        strokeStyle: "#e1fff7",

        lineWidth: 3,

        opacity: 0.9

      }

    });



  const mouse = Mouse.create(render.canvas);

  const mouseConstraint = MouseConstraint.create(engine, {

    mouse,

    constraint: {

      stiffness: 0.2,

      angularStiffness: 0,

      render: { visible: false }

    },

    collisionFilter: {

      mask: draggableCategory

    }

  });



  World.add(world, mouseConstraint);

  render.mouse = mouse;



  const controls = {

    left: false,

    right: false,

    jumpQueued: false

  };



  const leftKeys = new Set(["ArrowLeft", "KeyA"]);

  const rightKeys = new Set(["ArrowRight", "KeyD"]);

  const jumpKeys = new Set(["Space", "KeyW", "ArrowUp"]);



  window.addEventListener("keydown", event => {

    if (!event.repeat) {

      if (leftKeys.has(event.code)) controls.left = true;

      if (rightKeys.has(event.code)) controls.right = true;

      if (jumpKeys.has(event.code)) controls.jumpQueued = true;

    }



    if (event.code === "KeyR") {

      loadLevel(0);

    }

  });



  window.addEventListener("keyup", event => {

    if (leftKeys.has(event.code)) controls.left = false;

    if (rightKeys.has(event.code)) controls.right = false;

    if (jumpKeys.has(event.code)) controls.jumpQueued = false;

  });



  const levels = [
    {
      playerStart: { x: 140, y: height - 200 },
      exit: { x: width - 90, y: height - 420, width: 70, height: 90 },
      platforms: [
        { x: width * 0.32, y: height - 125, width: 260, height: 20 },
        { x: width * 0.78, y: height - 340, width: 200, height: 20 }
      ],
      draggables: [
        { type: "crate", x: 460, y: height - 220, size: 46, color: colors[0] },
        { type: "crate", x: 520, y: height - 260, size: 46, color: colors[1] },
        { type: "crate", x: 580, y: height - 300, size: 46, color: colors[2] },
        { type: "orb", x: 400, y: height - 160, radius: 24, color: colors[3] },
        { type: "orb", x: 720, y: height - 360, radius: 30, color: colors[4] },
        { type: "crate", x: 720, y: height - 200, size: 38, color: colors[1] }
      ]
    },
    {
      playerStart: { x: 120, y: height - 90 },
      exit: { x: width - 70, y: height - 420, width: 80, height: 90 },
      platforms: [
        { x: width * 0.25, y: height - 150, width: 70, height: 300 },
        { x: width * 0.38, y: 150, width: 70, height: 280 },
        { x: width * 0.51, y: height - 170, width: 70, height: 320 },
        { x: width * 0.64, y: 140, width: 70, height: 280 },
        { x: width * 0.77, y: height - 190, width: 70, height: 320 },
        { x: width * 0.9, y: 120, width: 60, height: 220 },
        { x: width * 0.9, y: height - 35, width: 140, height: 20 },
        { x: width * 0.9, y: 35, width: 140, height: 20 }
      ],
      draggables: [
        { type: "orb", x: 260, y: height - 200, radius: 26, color: colors[0] },
        { type: "crate", x: 360, y: 120, size: 36, color: colors[2] },
        { type: "orb", x: 460, y: height - 260, radius: 24, color: colors[4] },
        { type: "crate", x: 560, y: 120, size: 40, color: colors[1] },
        { type: "orb", x: 700, y: height - 260, radius: 28, color: colors[3] }
      ]
    },
    {
      playerStart: { x: 160, y: height - 220 },
      exit: { x: width - 110, y: height - 160, width: 80, height: 90 },
      platforms: [
        { x: width * 0.3, y: height - 80, width: 220, height: 20, angle: 0.05 },
        { x: width * 0.48, y: height - 140, width: 200, height: 20, angle: -0.05 },
        { x: width * 0.65, y: height - 210, width: 160, height: 18, angle: 0.04 },
        { x: width * 0.82, y: height - 280, width: 150, height: 18 },
        { x: width * 0.6, y: height - 320, width: 120, height: 18, angle: -0.08 }
      ],
      draggables: [
        { type: "orb", x: 360, y: height - 180, radius: 24, color: colors[4] },
        { type: "crate", x: 420, y: height - 250, size: 40, color: colors[0] },
        { type: "crate", x: 520, y: height - 220, size: 44, color: colors[2] },
        { type: "orb", x: 640, y: height - 320, radius: 26, color: colors[1] },
        { type: "crate", x: 720, y: height - 200, size: 36, color: colors[3] }
      ]
    },
    {
      playerStart: { x: 120, y: height - 110 },
      exit: { x: width * 0.18, y: height - 420, width: 70, height: 90 },
      platforms: [
        { x: width * 0.25, y: height - 160, width: 220, height: 20 },
        { x: width * 0.45, y: height - 220, width: 60, height: 240 },
        { x: width * 0.58, y: height - 110, width: 160, height: 20 },
        { x: width * 0.72, y: height - 260, width: 60, height: 260 },
        { x: width * 0.88, y: height - 340, width: 150, height: 18 },
        { x: width * 0.55, y: height - 380, width: 180, height: 18 }
      ],
      draggables: [
        { type: "crate", x: 300, y: height - 210, size: 40, color: colors[0] },
        { type: "orb", x: 430, y: height - 280, radius: 24, color: colors[2] },
        { type: "crate", x: 560, y: height - 300, size: 42, color: colors[4] },
        { type: "orb", x: 650, y: height - 220, radius: 28, color: colors[1] },
        { type: "crate", x: 800, y: height - 220, size: 36, color: colors[3] }
      ]
    },
    {
      playerStart: { x: width * 0.15, y: height - 120 },
      exit: { x: width - 120, y: height - 450, width: 80, height: 90 },
      platforms: [
        { x: width * 0.2, y: height - 160, width: 160, height: 18 },
        { x: width * 0.42, y: height - 220, width: 130, height: 18 },
        { x: width * 0.58, y: height - 300, width: 120, height: 18 },
        { x: width * 0.75, y: height - 360, width: 150, height: 18 },
        { x: width * 0.52, y: height - 420, width: 90, height: 18 }
      ],
      draggables: [
        { type: "crate", x: 240, y: height - 210, size: 36, color: colors[0] },
        { type: "crate", x: 300, y: height - 250, size: 36, color: colors[1] },
        { type: "orb", x: 380, y: height - 260, radius: 24, color: colors[3] },
        { type: "orb", x: 520, y: height - 340, radius: 28, color: colors[4] },
        { type: "crate", x: 620, y: height - 300, size: 40, color: colors[2] },
        { type: "orb", x: 720, y: height - 400, radius: 24, color: colors[1] }
      ]
    }
  ];

  let currentLevelIndex = 0;

  let levelBodies = [];

  let exitSensor = null;

  let levelComplete = false;

  let timerActive = false;

  let timerStart = null;



  const resetPlayerState = start => {

    controls.left = false;

    controls.right = false;

    controls.jumpQueued = false;

    Body.setPosition(player, start);

    Body.setVelocity(player, { x: 0, y: 0 });

    Body.setAngle(player, 0);

    Body.setAngularVelocity(player, 0);

  };



  const clearLevelBodies = () => {

    if (levelBodies.length) {

      levelBodies.forEach(body => World.remove(world, body));

    }

    levelBodies = [];

    exitSensor = null;

    mouseConstraint.body = null;

  };



  const updateHud = () => {

    levelIndicatorEl.textContent = `Level ${currentLevelIndex + 1}`;

    timerStart = performance.now();

    timerActive = true;

    timerEl.textContent = "Timer: 0.0s";

  };



  const buildDraggable = def =>

    def.type === "orb"

      ? createOrb(def.x, def.y, def.radius, def.color)

      : createCrate(def.x, def.y, def.size, def.color);



  const loadLevel = index => {

    const level = levels[index];

    if (!level) return;



    currentLevelIndex = index;

    levelComplete = false;

    clearLevelBodies();

    resetPlayerState(level.playerStart);



    const platformBodies = level.platforms.map(createPlatform);

    const draggableBodies = level.draggables.map(buildDraggable);

    exitSensor = createExitPortal(level.exit);



    levelBodies = [...platformBodies, ...draggableBodies, exitSensor];

    World.add(world, levelBodies);

    updateHud();

  };



  const advanceLevel = () => {

    if (levelComplete) return;

    levelComplete = true;

    timerActive = false;

    timerStart = null;



    if (currentLevelIndex + 1 < levels.length) {

      levelIndicatorEl.textContent = "Portal reached!";

      setTimeout(() => loadLevel(currentLevelIndex + 1), 600);

    } else {

      levelIndicatorEl.textContent = "All levels cleared!";

    }

  };



  const monitorTimer = () => {

    if (timerActive && timerStart) {

      const elapsed = (performance.now() - timerStart) / 1000;

      timerEl.textContent = `Timer: ${elapsed.toFixed(1)}s`;

    }



    requestAnimationFrame(monitorTimer);

  };



  monitorTimer();



  const groundedPairs = new Set();



  const isGroundedPair = pair => {

    if (pair.bodyA === player) {

      return pair.collision.normal.y < -0.5;

    }

    if (pair.bodyB === player) {

      return pair.collision.normal.y > 0.5;

    }

    return false;

  };



  const trackGroundedContacts = event => {

    event.pairs.forEach(pair => {

      if (isGroundedPair(pair)) {

        groundedPairs.add(pair.id);

      }

    });

  };



  const detectExitCollision = event => {

    if (!exitSensor || levelComplete) return;

    event.pairs.forEach(pair => {

      const { bodyA, bodyB } = pair;

      if ((bodyA === player && bodyB === exitSensor) || (bodyB === player && bodyA === exitSensor)) {

        advanceLevel();

      }

    });

  };



  const onCollisionStart = event => {

    trackGroundedContacts(event);

    detectExitCollision(event);

  };



  const onCollisionEnd = event => {

    event.pairs.forEach(pair => {

      groundedPairs.delete(pair.id);

    });

  };



  Events.on(engine, "collisionStart", onCollisionStart);

  Events.on(engine, "collisionActive", trackGroundedContacts);

  Events.on(engine, "collisionEnd", onCollisionEnd);



  const canJump = () => groundedPairs.size > 0;



  const moveForce = 0.0045;

  const maxHorizontalSpeed = 7.5;



  Events.on(engine, "beforeUpdate", () => {

    if (controls.left) {

      Body.applyForce(player, player.position, { x: -moveForce, y: 0 });

    }

    if (controls.right) {

      Body.applyForce(player, player.position, { x: moveForce, y: 0 });

    }



    const { x: vx, y: vy } = player.velocity;



    if (!controls.left && !controls.right) {

      Body.setVelocity(player, { x: vx * 0.9, y: vy });

    } else if (Math.abs(vx) > maxHorizontalSpeed) {

      Body.setVelocity(player, { x: Math.sign(vx) * maxHorizontalSpeed, y: vy });

    }



    if (controls.jumpQueued && canJump()) {

      Body.setVelocity(player, { x: player.velocity.x, y: -11 });

      controls.jumpQueued = false;

    }

  });



  window.addEventListener("blur", () => {

    controls.left = false;

    controls.right = false;

    controls.jumpQueued = false;

  });



  loadLevel(0);

})();